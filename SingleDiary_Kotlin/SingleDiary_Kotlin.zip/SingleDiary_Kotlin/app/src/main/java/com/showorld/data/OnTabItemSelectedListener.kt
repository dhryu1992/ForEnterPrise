package com.showorld.data

interface OnTabItemSelectedListener {
    public fun onTabSelected(position: Int)
    public fun showFragment2(item: Note)
}