package com.shuworld.databinding_expression;

public class UserProfile {
    public static final int GENDER_MALE = 0;
    public static final int GENDER_FEMALE = 1;

    public String name;
    public String phone;
    public String address;
    public int gender;
    public String ImageUrl;


/*    public String getGenderAsText() {
        return (gender == 1) ? "남성" : "여성";
    }*/
}
