package com.example.room_kotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "database-name").build()

        result_Text.text = db.todoDao().getAll().toString()

        addButton.setOnClickListener {
            db.todoDao().insert(Todo(todo_editText.toString()))
            result_Text.text = db.todoDao().getAll().toString()
        }
    }
}