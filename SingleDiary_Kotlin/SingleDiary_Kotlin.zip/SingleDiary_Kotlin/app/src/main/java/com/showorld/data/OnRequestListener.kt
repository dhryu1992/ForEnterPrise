package com.showorld.data

interface OnRequestListener {
    public fun onRequest(command: String)
}
