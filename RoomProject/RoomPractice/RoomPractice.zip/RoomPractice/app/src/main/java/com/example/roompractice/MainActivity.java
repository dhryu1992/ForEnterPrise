package com.example.roompractice;

import android.arch.lifecycle.ViewModelProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.roompractice.databinding.ActivityMainBinding;

import java.util.List;
import java.util.Observer;

public class MainActivity extends AppCompatActivity {

    private UserProfileViewModel model;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        model = new ViewModelProvider(this).get(UserProfileViewModel.class);
        model.userProfileList.observe(this, new Observer<List<UserProfile>>() {
            @Override
            public void onChanged(List<UserProfile> userProfileList) {
                updateUserProfileList(userProfileList);
            }
        });
    }

    private void updateUserProfileList(List<UserProfile> userProfileList) {
        String userListText = "사용자 목록";
        for (UserProfile userProfile : userProfileList) {
            userListText += "\n" + userProfile.id + ", " + userProfile.name + ", " + userProfile.phone + ", " + userProfile.address;
        }

        binding.userList.setText(userListText);
    }

    public void addUserProfile(View view) {
        UserProfile userProfile = new UserProfile();
        userProfile.name = binding.name.getText().toString();
        userProfile.phone = binding.phone.getText().toString();
        userProfile.address = binding.address.getText().toString();
        model.insert(userProfile);
    }
}